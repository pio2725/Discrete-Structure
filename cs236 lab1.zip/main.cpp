#include <iostream>
#include <fstream>
#include <string>
#include <cctype>

#include "Token.h"
#include "Scanner.h"

int main(int argc, char* argv[])
{
    std::string filename = argv[1];
    Scanner scan(filename);
    scan.Tokenize();
    

    return 0;
}