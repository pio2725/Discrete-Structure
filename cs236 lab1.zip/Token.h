#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <vector>

enum TokenType
{
	COMMA, PERIOD, Q_MARK, LEFT_PAREN, RIGHT_PAREN, COLON, COLON_DASH,
	MULTIPLY, ADD, SCHEMES, FACTS, RULES, QUERIES, ID, STRING, COMMENT,
	UNDEFINED, EOFILE
};

class Token
{
public:
	Token(TokenType tokentype, std::string value, int lineNum);
	~Token();
	void ToString();
	std::string TokentypeToString(TokenType ttype);
    
private:
	std::string value;
	int lineNum;
	TokenType tokentype;
};



