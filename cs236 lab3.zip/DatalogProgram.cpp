#include "DatalogProgram.h"


DatalogProgram::DatalogProgram()
{
	
}

DatalogProgram::~DatalogProgram()
{
}



void DatalogProgram::ToString()
{
	
}