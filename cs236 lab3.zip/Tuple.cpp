#include "Tuple.h"

Tuple::Tuple()
{
}


Tuple::~Tuple()
{
}
