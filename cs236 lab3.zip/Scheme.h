#ifndef SCHEME_H
#define SCHEME_H

#include <iostream>
#include <vector>
#include <string>

class Scheme : public std::vector<std::string>
{
public:
	Scheme();
	~Scheme();

	
private:
	
};

#endif