#include <iostream>
#include <fstream>
#include <string>
#include <cctype>

#include "Scanner.h"
#include "Parser.h"

int main(int argc, char* argv[])
{
    std::string filename = argv[1];
    Scanner scanthis(filename);
	scanthis.Tokenize();
	std::vector<Token> tokens = scanthis.getTokenVector();
	Parser parser;
	parser.Parse(tokens);

    return 0;
}
